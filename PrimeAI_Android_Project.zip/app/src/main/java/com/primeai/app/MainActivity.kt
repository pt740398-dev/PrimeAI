package com.primeai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Accent = Color(0xFF19A37A)
private val MainText = Color(0xFFF2F3F5)
private val Muted = Color(0xFF9DA3AD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeAiApp() }
    }
}

data class ChatMessage(val role: String, val content: String)

@Composable
fun PrimeAiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "prime_ai_secure", masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://integrate.api.nvidia.com/v1/chat/completions") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "meta/llama-3.1-8b-instruct") ?: "") }
    var draft by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var settingsOpen by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Bg, surface = Panel,
        onBackground = MainText, onSurface = MainText
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Prime AI", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MainText)
                    Text("Powered by NVIDIA NIM", fontSize = 12.sp, color = Muted)
                }
                IconButton(onClick = {
                    messages = emptyList()
                    error = ""
                }) { Icon(Icons.Default.Add, contentDescription = "New chat", tint = MainText) }
                IconButton(onClick = { settingsOpen = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = MainText)
                }
            }

            if (messages.isEmpty()) {
                Column(
                    Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("✦", color = Accent, fontSize = 42.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("What can I help with?", color = MainText, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Ask anything. Prime AI is ready.", color = Muted, fontSize = 14.sp)
                    Spacer(Modifier.height(24.dp))
                    Text("Tip: Add your NVIDIA API key in Settings to start chatting.", color = Muted, fontSize = 12.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(messages) { message ->
                        val isUser = message.role == "user"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                            Surface(
                                color = if (isUser) Color(0xFF24483F) else Panel,
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.widthIn(max = 320.dp)
                            ) {
                                Text(message.content, Modifier.padding(14.dp), color = MainText, fontSize = 15.sp)
                            }
                        }
                    }
                    if (loading) item {
                        Text("Prime AI is thinking…", color = Muted, modifier = Modifier.padding(8.dp))
                    }
                }
            }

            if (error.isNotBlank()) {
                Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
                    .background(Panel, RoundedCornerShape(26.dp)).padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = draft, onValueChange = { draft = it },
                    modifier = Modifier.weight(1f).padding(vertical = 10.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 15.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Accent),
                    decorationBox = { inner ->
                        Box {
                            if (draft.isEmpty()) Text("Message Prime AI…", color = Muted)
                            inner()
                        }
                    }
                )
                IconButton(
                    enabled = draft.isNotBlank() && !loading,
                    onClick = {
                        val prompt = draft.trim()
                        if (prompt.isNotEmpty()) {
                            draft = ""
                            val updated = messages + ChatMessage("user", prompt)
                            messages = updated
                            error = ""
                            if (apiKey.isBlank()) {
                                error = "API key missing. Open Settings and add your NVIDIA key."
                            } else {
                                loading = true
                                scope.launch {
                                    try {
                                        val answer = withContext(Dispatchers.IO) {
                                            callNim(endpoint, apiKey, model, updated)
                                        }
                                        messages = messages + ChatMessage("assistant", answer)
                                    } catch (e: Exception) {
                                        error = e.message ?: "Request failed. Check your connection and API settings."
                                    } finally { loading = false }
                                }
                            }
                        }
                    }
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = if (draft.isNotBlank() && !loading) Accent else Muted)
                }
            }
            Text("AI can make mistakes. Verify important information.", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 6.dp))
        }

        if (settingsOpen) {
            var keyInput by remember { mutableStateOf(apiKey) }
            var endpointInput by remember { mutableStateOf(endpoint) }
            var modelInput by remember { mutableStateOf(model) }
            AlertDialog(
                onDismissRequest = { settingsOpen = false },
                containerColor = Panel,
                title = { Text("API Settings", color = MainText) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("NVIDIA API key", color = Muted, fontSize = 12.sp)
                        OutlinedTextField(keyInput, { keyInput = it }, label = { Text("API key") }, singleLine = true)
                        Text("Chat completions URL", color = Muted, fontSize = 12.sp)
                        OutlinedTextField(endpointInput, { endpointInput = it }, label = { Text("Endpoint") }, singleLine = true)
                        Text("Model ID", color = Muted, fontSize = 12.sp)
                        OutlinedTextField(modelInput, { modelInput = it }, label = { Text("Model") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        apiKey = keyInput.trim()
                        endpoint = endpointInput.trim()
                        model = modelInput.trim()
                        prefs.edit().putString("api_key", apiKey)
                            .putString("endpoint", endpoint).putString("model", model).apply()
                        settingsOpen = false
                    }) { Text("Save", color = Accent) }
                },
                dismissButton = {
                    TextButton(onClick = { settingsOpen = false }) { Text("Cancel", color = Muted) }
                }
            )
        }
    }
}

private fun callNim(endpoint: String, apiKey: String, model: String, history: List<ChatMessage>): String {
    require(endpoint.startsWith("https://")) { "Endpoint must use HTTPS." }
    val url = URL(endpoint)
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Authorization", "Bearer $apiKey")
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("Accept", "application/json")
    }
    try {
        val msgArray = JSONArray()
        history.forEach { msg ->
            msgArray.put(JSONObject().put("role", msg.role).put("content", msg.content))
        }
        val body = JSONObject()
            .put("model", model)
            .put("messages", msgArray)
            .put("temperature", 0.7)
            .put("max_tokens", 2048)
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) {
            val detail = try { JSONObject(response).optString("detail", response) } catch (_: Exception) { response }
            throw IllegalStateException("NVIDIA API error ($code): ${detail.take(500)}")
        }
        val json = JSONObject(response)
        return json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    } finally {
        connection.disconnect()
    }
}
