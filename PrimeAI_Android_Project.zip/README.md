# Prime AI (Android)

A ChatGPT-style Android app using an OpenAI-compatible NVIDIA NIM chat-completions endpoint.

## Build
- Open this folder in Android Studio, or upload the project to GitHub.
- Use JDK 17 and Android SDK 35.
- Run `./gradlew assembleDebug` to build `app/build/outputs/apk/debug/app-debug.apk`.

## Configure
Open Prime AI → Settings and enter:
- NVIDIA API key
- Chat completions endpoint (default: `https://integrate.api.nvidia.com/v1/chat/completions`)
- Model ID available to your NVIDIA account (default is an example; change if unavailable)

The API key is stored using Android EncryptedSharedPreferences and is not included in the project source.

## Security note
For a public/released app, do not ship a shared provider key in an APK. APKs can be reverse engineered. Use a small authenticated backend that holds the provider key server-side. This starter stores a key entered by the app user in encrypted local preferences for personal testing.
