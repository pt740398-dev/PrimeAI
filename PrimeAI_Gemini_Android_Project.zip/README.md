# Prime AI (Gemini edition)

Android app project for building a debug APK with GitHub Actions.

## Features
- First-run welcome/profile screen (local demo profile; NOT real authentication)
- Dark Prime AI chat interface
- General, Study, Coding and Web-labelled response modes
- Gemini API key field in Settings
- Gemini `generateContent` request using `gemini-2.5-flash`

## Important limitations
- The profile screen is local-only. There is no real signup, password, account verification or cloud sync.
- The Web mode does not perform live web search.
- Image generation is not implemented.
- Chat messages are kept in memory and are not synced or persisted.
- API key is stored in local app preferences for this personal-use prototype. A key embedded/stored in a client APK can be extracted. Do not distribute this APK publicly with a private key; use a backend proxy for a public app.
- Gemini availability, age eligibility, free quotas and terms depend on Google's current account and regional policies. Check those before use.
- Build has not been run in this environment; use Actions and share any error log for debugging.

## Build
Run the `Prime AI Gemini APK Build` workflow from GitHub Actions. The project root contains `settings.gradle.kts`.
