package com.primeai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151923)
private val Panel2 = Color(0xFF1D2330)
private val Accent = Color(0xFF8B7CFF)
private val MainText = Color(0xFFF3F4F8)
private val Muted = Color(0xFF9AA3B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("prime_ai_local", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onBackground = MainText, onSurface = MainText
            )) {
                PrimeApp(
                    initialName = prefs.getString("name", "") ?: "",
                    initialEmail = prefs.getString("email", "") ?: "",
                    initialKey = prefs.getString("gemini_key", "") ?: "",
                    saveProfile = { n, e -> prefs.edit().putString("name", n).putString("email", e).apply() },
                    saveKey = { k -> prefs.edit().putString("gemini_key", k).apply() }
                )
            }
        }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun PrimeApp(
    initialName: String, initialEmail: String, initialKey: String,
    saveProfile: (String, String) -> Unit, saveKey: (String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var email by remember { mutableStateOf(initialEmail) }
    var apiKey by remember { mutableStateOf(initialKey) }
    var onboarded by remember { mutableStateOf(initialName.isNotBlank()) }
    var showSettings by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("General") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val scope = rememberCoroutineScope()

    if (!onboarded) {
        OnboardingScreen(
            name = name, onName = { name = it },
            email = email, onEmail = { email = it },
            onContinue = {
                if (name.isNotBlank()) {
                    saveProfile(name.trim(), email.trim())
                    onboarded = true
                }
            }
        )
        return
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).background(Accent, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Text("P", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("Prime AI", color = MainText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Gemini • Personal assistant", color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = { showProfile = true }) { Icon(Icons.Default.AccountCircle, null, tint = MainText) }
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, null, tint = MainText) }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("General", "Study", "Coding", "Web").forEach { item ->
                FilterChip(
                    selected = mode == item, onClick = { mode = item },
                    label = { Text(item, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Accent.copy(alpha = .24f),
                        selectedLabelColor = MainText
                    )
                )
            }
        }

        if (messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(68.dp).background(Accent.copy(alpha = .18f), CircleShape), contentAlignment = Alignment.Center) {
                    Text("P", color = Accent, fontSize = 34.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.height(18.dp))
                Text("What can I help with?", color = MainText, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Ask anything, learn something, or build something.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(24.dp))
                listOf("Explain a difficult topic simply", "Help me build an Android app", "Write and debug Kotlin code").forEach {
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(14.dp)).clickable { input = it }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Accent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(it, color = MainText, fontSize = 13.sp)
                    }
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(max = 310.dp).background(if (msg.fromUser) Color(0xFF302B55) else Panel, RoundedCornerShape(16.dp)).padding(13.dp)) {
                            Text(if (msg.fromUser) "You" else "Prime AI", color = if (msg.fromUser) Color(0xFFC9C2FF) else Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text(msg.text, color = MainText, fontSize = 14.sp, lineHeight = 20.sp)
                        }
                    }
                }
                if (busy) item { Text("Prime AI is thinking…", color = Muted, modifier = Modifier.padding(8.dp)) }
            }
        }

        if (error.isNotBlank()) Text(error, color = Color(0xFFFF8D8D), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))

        Row(Modifier.fillMaxWidth().padding(12.dp).background(Panel, RoundedCornerShape(22.dp)).padding(horizontal = 13.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f).padding(vertical = 9.dp),
                textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 14.sp),
                decorationBox = { inner -> if (input.isEmpty()) Text("Message Prime AI…", color = Muted, fontSize = 14.sp); inner() }
            )
            IconButton(
                enabled = !busy && input.isNotBlank(),
                onClick = {
                    val prompt = input.trim()
                    input = ""
                    messages.add(ChatMessage(prompt, true))
                    error = ""
                    busy = true
                    scope.launch {
                        try {
                            if (apiKey.isBlank()) throw IllegalStateException("Settings mein Gemini API key add karo.")
                            val answer = GeminiClient.reply(apiKey, mode, prompt)
                            messages.add(ChatMessage(answer, false))
                        } catch (e: Exception) {
                            error = e.message ?: "Request failed. Please try again."
                            messages.add(ChatMessage("I couldn't get a response. Check the API key, internet connection, and Gemini quota in Settings/provider dashboard.", false))
                        } finally { busy = false }
                    }
                }
            ) { Icon(Icons.Default.Send, null, tint = if (input.isNotBlank()) Accent else Muted) }
        }
        Text("AI can make mistakes • Keep your API key private", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
    }

    if (showSettings) {
        var draft by remember { mutableStateOf(apiKey) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Gemini API settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Paste your own Gemini API key. Never share it in chat or GitHub.", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(
                        value = draft, onValueChange = { draft = it },
                        label = { Text("Gemini API key") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true
                    )
                    Text("This personal-use build stores the key locally on this device. A production app should use a secure backend.", color = Muted, fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { apiKey = draft.trim(); saveKey(apiKey); showSettings = false }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }

    if (showProfile) {
        AlertDialog(
            onDismissRequest = { showProfile = false },
            title = { Text("Your profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Name: $name", color = MainText)
                    Text("Email: ${email.ifBlank { "Not added" }}", color = Muted)
                    Text("This is a local profile, not a real online login account.", color = Muted, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showProfile = false }) { Text("Done") } },
            dismissButton = { TextButton(onClick = { showProfile = false; onboarded = false }) { Text("Sign out") } }
        )
    }
}

@Composable
fun OnboardingScreen(name: String, onName: (String) -> Unit, email: String, onEmail: (String) -> Unit, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(26.dp), verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(58.dp).background(Accent, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Text("P", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(25.dp))
        Text("Welcome to Prime AI", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Your personal AI workspace", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(value = name, onValueChange = onName, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = email, onValueChange = onEmail, label = { Text("Email (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        Button(onClick = onContinue, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
            Text("Continue", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text("Demo profile only — no password or online account is created.", color = Muted, fontSize = 11.sp)
    }
}

object GeminiClient {
    suspend fun reply(apiKey: String, mode: String, prompt: String): String = withContext(Dispatchers.IO) {
        val model = "gemini-2.5-flash"
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        val instruction = when (mode) {
            "Coding" -> "You are Prime AI, a helpful programming assistant. Explain code clearly and provide safe, correct examples."
            "Study" -> "You are Prime AI, a patient study tutor. Explain concepts simply and encourage learning."
            "Web" -> "You are Prime AI. Answer from your knowledge and clearly say when live web access is unavailable. Do not pretend to browse."
            else -> "You are Prime AI, a helpful general assistant. Be clear, friendly, and accurate."
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048))
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        connection.disconnect()
        if (code !in 200..299) {
            val message = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
            throw IllegalStateException("Gemini API error ($code): ${message ?: response.take(250)}")
        }
        val root = JSONObject(response)
        val candidates = root.optJSONArray("candidates") ?: throw IllegalStateException("No response returned. Check model access or quota.")
        val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val output = buildString {
            if (parts != null) for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
        }.trim()
        if (output.isBlank()) throw IllegalStateException("Gemini returned an empty response.")
        output
    }
}
