package com.primeai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF090A0E)
private val Panel = Color(0xFF171B27)
private val Purple = Color(0xFF8974F5)
private val SoftPurple = Color(0xFF302B55)
private val White = Color(0xFFF4F2FA)
private val Muted = Color(0xFF9A9AAA)
private val ErrorRed = Color(0xFFFF9AA8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeAiApp() }
    }
}

private data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
private fun PrimeAiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("prime_ai_settings", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var profileName by remember { mutableStateOf(prefs.getString("profile_name", "You") ?: "You") }
    var selectedMode by remember { mutableStateOf("General") }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf("") }
    var previousInteractionId by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple,
        onBackground = White, onSurface = White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg)
        ) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 17.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(58.dp).background(Purple, RoundedCornerShape(17.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("P", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Prime AI", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = White)
                    Text("Gemini  ·  Personal assistant", color = Muted, fontSize = 13.sp)
                }
                IconButton(onClick = { showProfile = true }) {
                    Icon(Icons.Default.Person, contentDescription = "Profile", tint = White)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = White)
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("General", "Study", "Coding", "Web").forEach { mode ->
                    val selected = selectedMode == mode
                    Surface(
                        onClick = { selectedMode = mode },
                        color = if (selected) SoftPurple else Bg,
                        shape = RoundedCornerShape(13.dp),
                        border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, Color.Gray),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(Modifier.padding(vertical = 13.dp), contentAlignment = Alignment.Center) {
                            Text(mode, color = White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Column(Modifier.fillMaxWidth().padding(top = 50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Welcome to Prime AI", color = Purple, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Ask anything to get started.", color = Muted)
                        }
                    }
                }
                items(messages) { message ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            Modifier.widthIn(max = 310.dp)
                                .background(if (message.fromUser) SoftPurple else Panel, RoundedCornerShape(22.dp))
                                .padding(16.dp)
                        ) {
                            Text(if (message.fromUser) profileName else "Prime AI", color = if (message.fromUser) Color(0xFFC9BFFF) else Purple, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(message.text, color = White, fontSize = 15.sp, lineHeight = 23.sp)
                        }
                    }
                }
                if (busy) item { Text("Prime AI is thinking…", color = Purple, modifier = Modifier.padding(8.dp)) }
                if (errorText.isNotBlank()) item { Text(errorText, color = ErrorRed, fontSize = 13.sp) }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)
                    .background(Panel, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    textStyle = TextStyle(color = White, fontSize = 16.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Purple),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (!busy && draft.isNotBlank()) {
                            val text = draft.trim(); draft = ""
                            sendMessage(text, selectedMode, apiKey, previousInteractionId, messages, scope,
                                onBusy = { busy = it },
                                onInteraction = { previousInteractionId = it },
                                onError = { errorText = it })
                        }
                    }),
                    decorationBox = { inner ->
                        Box {
                            if (draft.isEmpty()) Text("Message Prime AI…", color = Muted, fontSize = 16.sp)
                            inner()
                        }
                    }
                )
                IconButton(
                    enabled = !busy && draft.isNotBlank(),
                    onClick = {
                        val text = draft.trim()
                        if (text.isNotEmpty()) {
                            draft = ""
                            sendMessage(text, selectedMode, apiKey, previousInteractionId, messages, scope,
                                onBusy = { busy = it },
                                onInteraction = { previousInteractionId = it },
                                onError = { errorText = it })
                        }
                    }
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = if (busy) Muted else Purple)
                }
            }
            Text(
                "AI can make mistakes  ·  Keep your API key private",
                color = Muted, fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 12.dp, top = 2.dp)
            )
        }

        if (showSettings) {
            var keyInput by remember { mutableStateOf(apiKey) }
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Gemini Settings") },
                text = {
                    Column {
                        Text("Model: gemini-3.8-flash", color = Purple, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Text("Gemini API key", color = White)
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = keyInput, onValueChange = { keyInput = it },
                            singleLine = true, visualTransformation = PasswordVisualTransformation(),
                            placeholder = { Text("Paste your API key") }
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("For personal testing only. A key stored in an APK can be extracted. Do not publish this APK with your private key.", color = Muted, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        apiKey = keyInput.trim()
                        prefs.edit().putString("gemini_key", apiKey).apply()
                        showSettings = false
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
            )
        }

        if (showProfile) {
            var nameInput by remember { mutableStateOf(profileName) }
            AlertDialog(
                onDismissRequest = { showProfile = false },
                title = { Text("Profile") },
                text = {
                    OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Your name") }, singleLine = true)
                },
                confirmButton = {
                    TextButton(onClick = {
                        profileName = nameInput.ifBlank { "You" }
                        prefs.edit().putString("profile_name", profileName).apply()
                        showProfile = false
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { showProfile = false }) { Text("Cancel") } }
            )
        }
    }
}

private fun sendMessage(
    prompt: String,
    mode: String,
    apiKey: String,
    previousId: String,
    messages: MutableList<ChatMessage>,
    scope: kotlinx.coroutines.CoroutineScope,
    onBusy: (Boolean) -> Unit,
    onInteraction: (String) -> Unit,
    onError: (String) -> Unit
) {
    messages.add(ChatMessage(prompt, true))
    onError("")
    if (apiKey.isBlank()) {
        messages.add(ChatMessage("Open Settings and add your Gemini API key first.", false))
        return
    }
    onBusy(true)
    scope.launch {
        try {
            val result = withContext(Dispatchers.IO) {
                val systemPrompt = when (mode) {
                    "Study" -> "You are Prime AI, a patient study tutor. Answer directly and clearly. Prefer concise explanations, using steps only when useful."
                    "Coding" -> "You are Prime AI, a careful programming assistant. Give the direct solution first and keep explanations concise. Include code when useful."
                    "Web" -> "You are Prime AI. You do not have live web browsing in this app; be transparent when information may be outdated. Keep answers concise."
                    else -> "You are Prime AI, a helpful personal assistant. Be accurate and friendly. Answer directly in a concise way; expand only when asked."
                }
                val body = JSONObject().put("model", "gemini-3.8-flash")
                    .put("input", prompt)
                    .put("system_instruction", systemPrompt)
                    .put("generation_config", JSONObject().put("max_output_tokens", 1200))
                if (previousId.isNotBlank()) body.put("previous_interaction_id", previousId)

                var lastError: Exception? = null
                for (attempt in 0..2) {
                    val connection = (URL("https://generativelanguage.googleapis.com/v1beta/interactions")
                        .openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 20000
                        readTimeout = 60000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("x-goog-api-key", apiKey)
                    }
                    try {
                        connection.outputStream.use {
                            it.write(body.toString().toByteArray(Charsets.UTF_8))
                        }
                        val code = connection.responseCode
                        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

                        if (code == 503 || code == 429) {
                            val message = try {
                                JSONObject(response).optJSONObject("error")?.optString("message")
                                    ?: "Gemini is temporarily busy (HTTP $code)."
                            } catch (_: Exception) { "Gemini is temporarily busy (HTTP $code)." }
                            if (attempt < 2) {
                                lastError = IllegalStateException(message)
                                Thread.sleep(1000L * (attempt + 1))
                                continue
                            }
                            throw IllegalStateException("Gemini API error ($code): $message")
                        }

                        if (code !in 200..299) {
                            val message = try {
                                JSONObject(response).optJSONObject("error")?.optString("message")
                                    ?: "Gemini returned HTTP $code"
                            } catch (_: Exception) { "Gemini returned HTTP $code: $response" }
                            throw IllegalStateException("Gemini API error ($code): $message")
                        }

                        val json = JSONObject(response)
                        val interactionId = json.optString("id", "")
                        val reply = extractOutputText(json)
                        if (reply.isBlank()) throw IllegalStateException("Gemini returned an empty response. Try again.")
                        return@withContext Pair(interactionId, reply)
                    } catch (e: java.net.UnknownHostException) {
                        lastError = e
                        if (attempt == 2) {
                            throw IllegalStateException(
                                "Prime AI cannot resolve Google's Gemini server address. The app has INTERNET permission; check the phone's connection or Private DNS, then retry.", e
                            )
                        }
                        Thread.sleep(1000L * (attempt + 1))
                    } catch (e: java.net.SocketTimeoutException) {
                        lastError = e
                        if (attempt == 2) throw IllegalStateException(
                            "Connection to Gemini timed out. Check your internet connection and try again.", e
                        )
                        Thread.sleep(1000L * (attempt + 1))
                    } finally {
                        connection.disconnect()
                    }
                }
                throw IllegalStateException(lastError?.message ?: "Gemini request failed. Please try again.")
            }
            onInteraction(result.first)
            messages.add(ChatMessage(result.second, false))
        } catch (e: Exception) {
            messages.add(ChatMessage("I couldn't get a response. ${e.message ?: "Check your connection and API settings."}", false))
        } finally {
            onBusy(false)
        }
    }
}

private fun extractOutputText(json: JSONObject): String {
    val direct = json.optString("output_text", "")
    if (direct.isNotBlank() && direct != "null") return direct
    val steps = json.optJSONArray("steps") ?: JSONArray()
    val collected = StringBuilder()
    for (i in 0 until steps.length()) {
        val step = steps.optJSONObject(i) ?: continue
        if (step.optString("type") != "model_output") continue
        val content = step.optJSONArray("content") ?: continue
        for (j in 0 until content.length()) {
            val part = content.optJSONObject(j) ?: continue
            if (part.optString("type") == "text") collected.append(part.optString("text"))
        }
    }
    return collected.toString()
}
