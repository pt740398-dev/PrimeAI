# Prime AI — Gemini Interactions API

This is a complete Android Studio source project for Prime AI.

## Build
- Open the project in Android Studio, or upload the complete contents to the root of a GitHub repository.
- Run the GitHub Actions workflow `Prime AI Gemini APK Build`.
- Download the `Prime-AI-Gemini-APK` artifact.

## Gemini setup
1. Install the app.
2. Open Settings.
3. Add your Gemini API key.
4. Send a message.

The app uses Google's Gemini Interactions REST endpoint:
`https://generativelanguage.googleapis.com/v1beta/interactions`
with model `gemini-3.8-flash`.

## Important limitations
- The Web mode does not perform live web browsing; it is transparent about this.
- This prototype stores the API key locally in app preferences. A key embedded in or stored by a distributed APK can be extracted. For a public release, use a secure backend proxy and never commit API keys to GitHub.
- This source project has not been compiled on a local Android SDK in this environment. Run the included GitHub Actions workflow to verify the build.
