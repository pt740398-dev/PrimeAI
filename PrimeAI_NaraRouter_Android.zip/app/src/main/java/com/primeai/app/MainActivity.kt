package com.primeai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Accent = Color(0xFF19A37A)
private val MainText = Color(0xFFF2F3F5)
private val Muted = Color(0xFF9DA3AD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeAiApp() }
    }
}

data class ChatMessage(val role: String, val content: String)

@Composable
fun PrimeAiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember {
        val master = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(context, "prime_ai_secure", master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://router.bynara.id/v1/chat/completions") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "auto/bynara") ?: "") }
    var draft by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var settingsOpen by remember { mutableStateOf(false) }
    var loginOpen by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf(prefs.getString("profile_email", "") ?: "") }
    var displayName by remember { mutableStateOf(prefs.getString("profile_name", "") ?: "") }
    var mode by remember { mutableStateOf("General") }

    MaterialTheme(colorScheme = darkColorScheme(primary=Accent, background=Bg, surface=Panel, onBackground=MainText, onSurface=MainText)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal=16.dp, vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Prime AI", fontSize=22.sp, fontWeight=FontWeight.Bold, color=MainText)
                    Text("Nara Router • ${displayName.ifBlank { "AI assistant" }}", fontSize=11.sp, color=Muted)
                }
                IconButton(onClick={ messages=emptyList(); error="" }) { Icon(Icons.Default.Add, "New chat", tint=MainText) }
                IconButton(onClick={ loginOpen=true }) { Icon(Icons.Default.AccountCircle, "Profile", tint=MainText) }
                IconButton(onClick={ settingsOpen=true }) { Icon(Icons.Default.Settings, "Settings", tint=MainText) }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal=10.dp, vertical=8.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf("General","Study","App/Web","Image prompt").forEach { item ->
                    FilterChip(selected=mode==item, onClick={mode=item}, label={Text(item, fontSize=11.sp)})
                }
            }
            if (messages.isEmpty()) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("✦", color=Accent, fontSize=44.sp)
                    Text("What can I help with?", color=MainText, fontSize=24.sp, fontWeight=FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(when(mode) {
                        "Study" -> "Explain topics, solve practice problems and make revision notes."
                        "App/Web" -> "Plan apps, write code and debug your projects."
                        "Image prompt" -> "Create detailed prompts for image generators."
                        else -> "Ask anything. Prime AI is ready."
                    }, color=Muted, fontSize=13.sp)
                    Spacer(Modifier.height(20.dp))
                    Text("Add your Nara Router key in Settings to start.", color=Muted, fontSize=12.sp)
                }
            } else {
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding=PaddingValues(14.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    items(messages) { msg ->
                        val user = msg.role=="user"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=if(user) Arrangement.End else Arrangement.Start) {
                            Surface(color=if(user) Color(0xFF24483F) else Panel, shape=RoundedCornerShape(18.dp), modifier=Modifier.widthIn(max=330.dp)) {
                                Text(msg.content, Modifier.padding(14.dp), color=MainText, fontSize=14.sp)
                            }
                        }
                    }
                    if(loading) item { Text("Prime AI is thinking…", color=Muted) }
                }
            }
            if(error.isNotBlank()) Text(error, color=Color(0xFFFF8A80), fontSize=12.sp, modifier=Modifier.padding(horizontal=14.dp))
            Row(Modifier.fillMaxWidth().padding(12.dp).background(Panel, RoundedCornerShape(25.dp)).padding(start=16.dp,end=6.dp,top=6.dp,bottom=6.dp), verticalAlignment=Alignment.CenterVertically) {
                BasicTextField(value=draft, onValueChange={draft=it}, modifier=Modifier.weight(1f).padding(vertical=10.dp),
                    textStyle=androidx.compose.ui.text.TextStyle(color=MainText,fontSize=15.sp),
                    decorationBox={ inner -> Box { if(draft.isEmpty()) Text("Message Prime AI…", color=Muted); inner() } })
                IconButton(enabled=draft.isNotBlank() && !loading, onClick={
                    val prompt=draft.trim(); if(prompt.isNotEmpty()) {
                        draft=""; val userHistory=messages+ChatMessage("user",prompt); messages=userHistory; error=""
                        if(apiKey.isBlank()) error="API key missing. Open Settings and add your Nara Router key."
                        else {
                            loading=true
                            scope.launch {
                                try {
                                    val sys = when(mode) {
                                        "Study" -> "You are Prime AI Study Tutor. Explain clearly step by step, encourage learning, and do not simply provide answers to active tests."
                                        "App/Web" -> "You are Prime AI coding assistant. Help plan, build, explain and debug Android apps and websites. Give complete, practical code when asked."
                                        "Image prompt" -> "You are Prime AI image-prompt assistant. Write detailed, original prompts for image generators. Be clear that this chat endpoint returns text, not generated image files."
                                        else -> "You are Prime AI, a helpful and accurate assistant."
                                    }
                                    val routedModel = if (mode == "App/Web" && !model.endsWith(":online")) "$model:online" else model
                                    val answer=withContext(Dispatchers.IO){ callRouter(endpoint,apiKey,routedModel,sys,userHistory) }
                                    messages=messages+ChatMessage("assistant",answer)
                                } catch(e:Exception) { error=e.message ?: "Request failed. Check API settings and internet." }
                                finally { loading=false }
                            }
                        }
                    }
                }) { Icon(Icons.Default.Send,"Send",tint=if(draft.isNotBlank()&&!loading) Accent else Muted) }
            }
            Text("AI can make mistakes. Verify important information.", color=Muted, fontSize=10.sp, modifier=Modifier.align(Alignment.CenterHorizontally).padding(bottom=6.dp))
        }

        if(settingsOpen) {
            var k by remember { mutableStateOf(apiKey) }; var ep by remember { mutableStateOf(endpoint) }; var m by remember { mutableStateOf(model) }
            AlertDialog(onDismissRequest={settingsOpen=false}, containerColor=Panel, title={Text("Nara Router settings",color=MainText)},
                text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(k,{k=it},label={Text("API key")},singleLine=true)
                    OutlinedTextField(ep,{ep=it},label={Text("Chat completions endpoint")},singleLine=true)
                    OutlinedTextField(m,{m=it},label={Text("Model ID")},singleLine=true)
                }},
                confirmButton={TextButton(onClick={
                    apiKey=k.trim(); endpoint=ep.trim(); model=m.trim()
                    prefs.edit().putString("api_key",apiKey).putString("endpoint",endpoint).putString("model",model).apply()
                    settingsOpen=false
                }){Text("Save",color=Accent)}},
                dismissButton={TextButton(onClick={settingsOpen=false}){Text("Cancel",color=Muted)}})
        }
        if(loginOpen) {
            var n by remember { mutableStateOf(displayName) }; var e by remember { mutableStateOf(email) }
            AlertDialog(onDismissRequest={loginOpen=false}, containerColor=Panel, title={Text("Profile",color=MainText)},
                text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("Local profile only — cloud login and sync need a secure authentication backend.",color=Muted,fontSize=12.sp)
                    OutlinedTextField(n,{n=it},label={Text("Display name")},singleLine=true)
                    OutlinedTextField(e,{e=it},label={Text("Email (optional)")},singleLine=true)
                }},
                confirmButton={TextButton(onClick={
                    displayName=n.trim(); email=e.trim()
                    prefs.edit().putString("profile_name",displayName).putString("profile_email",email).apply()
                    loginOpen=false
                }){Text("Save profile",color=Accent)}},
                dismissButton={TextButton(onClick={loginOpen=false}){Text("Close",color=Muted)}})
        }
    }
}

private fun callRouter(endpoint:String,key:String,model:String,systemPrompt:String,history:List<ChatMessage>):String {
    require(endpoint.startsWith("https://")) { "Endpoint must use HTTPS." }
    val conn=(URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod="POST"; connectTimeout=20000; readTimeout=60000; doOutput=true
        setRequestProperty("Authorization","Bearer $key")
        setRequestProperty("Content-Type","application/json")
        setRequestProperty("Accept","application/json")
    }
    try {
        val arr=JSONArray().put(JSONObject().put("role","system").put("content",systemPrompt))
        history.forEach { arr.put(JSONObject().put("role",it.role).put("content",it.content)) }
        val payload=JSONObject().put("model",model).put("messages",arr).put("temperature",0.7).put("max_tokens",2048)
        conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
        val code=conn.responseCode
        val stream=if(code in 200..299) conn.inputStream else conn.errorStream
        val raw=stream.bufferedReader().use{it.readText()}
        if(code !in 200..299) throw IllegalStateException("Nara Router error ($code): ${raw.take(400)}")
        return JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    } finally { conn.disconnect() }
}
