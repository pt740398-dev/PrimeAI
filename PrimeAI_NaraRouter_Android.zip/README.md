# Prime AI Android

Android AI assistant starter configured for Nara Router.

## Nara Router API
- Chat endpoint: `https://router.bynara.id/v1/chat/completions`
- Default model: `auto/bynara`
- Auth: `Authorization: Bearer YOUR_NARA_ROUTER_KEY`
- Web mode appends `:online` to the model to request Nara Router's web tools.

Enter your own API key in the app Settings. Never commit it to GitHub or embed it in source code.

## Included
- Chat UI and in-session conversation history
- Nara Router OpenAI-compatible chat request
- Study tutor mode
- App/Web coding mode with Nara Router online web-search mode
- Image prompt-writing mode
- Local profile preferences (display name/email)
- Encrypted local storage for the API key
- GitHub Actions APK workflow

## Not yet included
- Actual image file generation/display. Nara Router documents a separate image-generation API at `https://api-images.bynara.id/v1/images/generations`; it needs a dedicated UI and response/image handling.
- Real account signup/login, password reset, and cloud chat sync. The profile screen is local-only and is NOT authentication.
- Secure production backend. For a released app, keep the Nara API key on a server, not inside an APK. The current personal-use starter stores the key encrypted on the device, but APKs can still be reverse engineered.

## Build
Use JDK 17, Android SDK 35, Gradle 8.9. Run `gradle assembleDebug`.
